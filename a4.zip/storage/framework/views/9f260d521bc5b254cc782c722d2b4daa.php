<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Author Dashboard</h1>
                <p>Welcome, <?php echo e(auth()->user()->name); ?>.</p>
                <p>
                    <a href="<?php echo e(route('author.posts.index')); ?>">Click here to view your posts.</a>
                </p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.author', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog_assignment1\resources\views/author/dashboard.blade.php ENDPATH**/ ?>