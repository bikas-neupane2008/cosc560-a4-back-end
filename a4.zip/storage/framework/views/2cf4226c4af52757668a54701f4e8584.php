<!-- resources/views/posts/show.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 offset-md-2">
        <h1 class="mb-4"><?php echo e($post->title); ?></h1>
        <div class="d-flex justify-content-between">
            <p class="mb-0">Updated At: <?php echo e($post->updated_at->setTimezone('Australia/Sydney')->format('D, d M, Y h:i:s A')); ?></p>
            <p class="mb-0">Updated By:
                <?php echo e($post->user ? $post->user->email : 'Unknown'); ?>

            </p>
        </div>
        <hr>
        </ul>
        <p><?php echo e($post->content); ?></p>
        <a href="<?php echo e(route('user.posts.index')); ?>" class="btn btn-info">Back to Posts</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog_assignment1\resources\views/user/posts/show.blade.php ENDPATH**/ ?>