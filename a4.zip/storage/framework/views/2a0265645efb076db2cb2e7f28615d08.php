<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Admin Dashboard</h1>
                <p>Welcome, <?php echo e(auth()->user()->name); ?>.</p>
                <p>
                    <a href="<?php echo e(route('admin.posts.index')); ?>">Click here to view all Posts.</a>
                </p>
                <p>
                    <a href="<?php echo e(route('admin.users.index')); ?>">Click here to view all Users.</a>
                </p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog_assignment1\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>