<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h1 class="mb-4">Edit User</h1>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
            <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST" class="d-inline"
                onsubmit="return confirm('Are you sure you want to update this user?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>" required>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" required>
                </div>

                <div class="form-group">
                    <label for="role">Role</label>
                    <select name="role" class="form-control" required>
                        <option value="admin" <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>Admin</option>
                        <option value="author" <?php echo e($user->role == 'author' ? 'selected' : ''); ?>>Author</option>
                        <option value="user" <?php echo e($user->role == 'user' ? 'selected' : ''); ?>>User</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="password">New Password <small>(leave blank to keep current password)</small></label>
                    <input type="password" name="password" class="form-control">
                </div>

                <div class="form-group">
                    <label for="password_confirmation">Confirm New Password</label>
                    <input type="password" name="password_confirmation" class="form-control">
                </div>
                <br>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-info d-inline">Back to Users</a>
                <button type="submit" class="btn btn-success">Update</button>
            </form>

            <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" class="d-inline"
                onsubmit="return confirm('Are you sure you want to delete this user? All posts by this user will also be deleted.');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Delete</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog_assignment1\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>