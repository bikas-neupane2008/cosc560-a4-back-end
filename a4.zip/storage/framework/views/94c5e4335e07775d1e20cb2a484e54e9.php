<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <h1 class="mb-4"><?php echo e($post->title); ?></h1>
            <div class="d-flex justify-content-between">
                <p class="mb-0">Updated At:
                    <?php echo e($post->updated_at->setTimezone('Australia/Sydney')->format('D, d M, Y h:i:s A')); ?></p>
                    <p class="mb-0">Updated By:
                        <?php echo e($post->user ? $post->user->email : 'Unknown'); ?>

                    </p>
            </div>
            <hr>
            </ul>
            <p><?php echo e($post->content); ?></p>
            <a href="<?php echo e(route('admin.posts.index')); ?>" class="btn btn-info">Back to Posts</a>
            <a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>" class="btn btn-secondary">Edit</a>
            <form action="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" method="POST" style="display: inline-block;"
                onsubmit="return confirm('Are you sure you want to delete this post?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Delete</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog_assignment1\resources\views/admin/posts/show.blade.php ENDPATH**/ ?>