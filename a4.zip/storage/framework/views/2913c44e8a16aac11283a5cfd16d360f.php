<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <h1 class="mb-4">Manage Users</h1>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary mb-4">Create New User</a>

        <div class="row">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">
                                <a href="<?php echo e(route('admin.users.show', $user->id)); ?>"><?php echo e($user->name); ?></a>
                            </h5>
                            <p class="card-text">Role: <?php echo e(ucfirst($user->role)); ?></p>
                            <p class="card-text">Email: <?php echo e($user->email); ?></p>
                        </div>
                        <div class="card-footer">
                            <small class="text-muted">Joined At: <?php echo e($user->created_at->setTimezone('Australia/Sydney')->format('D, d M, Y h:i:s A')); ?></small>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="d-flex justify-content-center">
            <?php echo e($users->links('vendor.pagination.bootstrap-5')); ?> <!-- Pagination links -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog_assignment1\resources\views/admin/users/index.blade.php ENDPATH**/ ?>