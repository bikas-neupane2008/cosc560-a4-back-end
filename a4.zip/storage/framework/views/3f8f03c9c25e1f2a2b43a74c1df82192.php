<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 offset-md-2">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <h1 class="mb-4"><?php echo e($user->name); ?></h1>
        <div class="d-flex justify-content-between">
            <p class="mb-0">Email: <?php echo e($user->email); ?></p>
            <p class="mb-0">Role: <?php echo e(ucfirst($user->role)); ?></p>
        </div>
        <div class="d-flex justify-content-between mt-2">
            <p class="mb-0">Joined At: <?php echo e($user->created_at->setTimezone('Australia/Sydney')->format('D, d M, Y h:i:s A')); ?></p>
            <p class="mb-0">Last Updated: <?php echo e($user->updated_at->setTimezone('Australia/Sydney')->format('D, d M, Y h:i:s A')); ?></p>
        </div>
        <hr>
        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-info">Back to Users</a>
        <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-secondary">Edit</a>
        <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" class="d-inline"
            onsubmit="return confirm('Are you sure you want to delete this user? All posts by this user will also be deleted.');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Delete</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog_assignment1\resources\views/admin/users/show.blade.php ENDPATH**/ ?>